# Build Kathmandu Valley Offline Navigator from a phone

You do not need a PC for the build. GitHub Actions builds the Android project on a GitHub-hosted runner.

## 1. Create a GitHub repository

On your phone, open GitHub in Chrome or the GitHub app and create a new repository, for example:

`KathmanduValleyOfflineNavigator`

For the simplest setup, make it **Public**. Do not put passwords, API keys, keystores, or other secrets in the repository.

## 2. Upload this project

Extract this ZIP on your phone first. Upload the **contents of the `KathmanduValleyOfflineMaps` folder** to the root of the GitHub repository.

The repository root should contain:

- `.github/workflows/build.yml`
- `.github/workflows/release.yml`
- `app/`
- `tools/`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`

Do not upload the outer ZIP file as the only repository file.

## 3. Start the cloud build

On GitHub:

1. Open your repository.
2. Tap **Actions**.
3. Select **Build APK for Phone**.
4. Tap **Run workflow**.
5. Choose `main` (or your default branch).
6. Tap **Run workflow** again.

The workflow installs JDK 17, Android SDK 35 and Gradle 8.10.2, then builds the debug APK.

## 4. Download the APK on your phone

After the workflow finishes with a green check:

1. Open the completed workflow run.
2. Scroll to **Artifacts**.
3. Download `KathmanduValleyOfflineNavigator-debug-apk`.
4. Extract the downloaded artifact if your phone saves it as a ZIP.
5. Open `app-debug.apk`.
6. Allow your browser/file manager to install unknown apps if Android asks.
7. Install it.

The debug APK is signed with the standard debug key and is suitable for testing on your own phone.

## 5. Important: map/routing data

Building the APK does **not** automatically put the complete Kathmandu Valley OSM routing database inside it.

The current application still requires its supported offline map/routing data to be installed or generated. The data-pipeline files are under `tools/data-pipeline/`.

Therefore:

**APK build = installable app binary**

**Production offline data pack = complete offline map/search/routing dataset**

Both are required for the final navigation product.

## 6. Play Store release

For Google Play, use a properly signed release/AAB build and keep the upload keystore backed up securely. Never commit the keystore or passwords to GitHub.
