#!/usr/bin/env bash
set -euo pipefail

# Production data-pack helper. Requires Docker + curl.
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
OUT="$ROOT/data/kathmandu-valley"
mkdir -p "$OUT/osm" "$OUT/search" "$OUT/brouter/segments4"
PBF_URL="https://download.geofabrik.de/asia/nepal-latest.osm.pbf"
PBF="$OUT/osm/nepal-latest.osm.pbf"
BBOX="85.20,27.55,85.55,27.85"

printf '\n[1/4] Download current Nepal OSM extract\n'
curl -L --fail --retry 3 -o "$PBF" "$PBF_URL"

printf '\n[2/4] Clip to Kathmandu Valley + safety buffer\n'
docker run --rm -v "$OUT/osm:/work" ghcr.io/osmcode/osmium:latest \
  extract -b "$BBOX" /work/nepal-latest.osm.pbf -o /work/kathmandu-valley.osm.pbf --overwrite

printf '\n[3/4] Install the official BRouter segment tile covering the Valley\n'
# Kathmandu Valley (roughly 85E/27N) is covered by BRouter's E85_N25 5x5 tile.
# BRouter documents these weekly-built rd5 tiles as the native offline routing format.
curl -L --fail --retry 3 -o "$OUT/brouter/segments4/E85_N25.rd5" \
  "https://brouter.de/brouter/segments4/E85_N25.rd5"

printf '\n[4/4] Build offline named-place search source\n'
docker run --rm -v "$OUT:/data" ghcr.io/osmcode/osmium:latest \
  tags-filter /data/osm/kathmandu-valley.osm.pbf \
  nwr/name -o /data/search/named.osm.pbf --overwrite

docker run --rm -v "$OUT:/data" ghcr.io/osmcode/osmium:latest \
  export /data/search/named.osm.pbf -f geojsonseq > "$OUT/search/named.geojsonseq"

python3 - "$OUT/search/named.geojsonseq" "$OUT/search/places.sqlite" <<'PY'
import json, sqlite3, sys
src, db = sys.argv[1:]
con = sqlite3.connect(db)
con.execute("DROP TABLE IF EXISTS places")
con.execute("CREATE TABLE places(id INTEGER PRIMARY KEY,name TEXT,name_ne TEXT,type TEXT,lat REAL,lon REAL)")
with open(src, encoding="utf-8") as fh:
    for line in fh:
        if not line.strip(): continue
        f=json.loads(line); p=f.get("properties",{}); g=f.get("geometry") or {}
        name=p.get("name") or p.get("name:en") or p.get("name:ne")
        coords=g.get("coordinates")
        if not name or not coords: continue
        if g.get("type") == "Point": lon,lat=coords
        elif g.get("type") == "LineString": lon,lat=coords[len(coords)//2]
        else: continue
        typ=p.get("amenity") or p.get("highway") or p.get("tourism") or p.get("shop") or "place"
        con.execute("INSERT INTO places(name,name_ne,type,lat,lon) VALUES(?,?,?,?,?)",
                    (name,p.get("name:ne"),typ,lat,lon))
con.commit()
con.execute("CREATE INDEX idx_places_name ON places(name)")
con.execute("CREATE INDEX idx_places_name_ne ON places(name_ne)")
con.close()
PY
rm -f "$OUT/search/named.osm.pbf" "$OUT/search/named.geojsonseq"
printf '\nData pack generated at %s\n' "$OUT"
