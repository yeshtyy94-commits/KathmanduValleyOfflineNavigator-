# Kathmandu Valley production data pipeline

This pipeline is intentionally separate from the Android APK because routing and
OSM data are large and must be regenerated when the map changes.

## Requirements

- Docker
- curl
- Internet for the one-time data build

## Build

```bash
./tools/data-pipeline/build-valley-data.sh
```

The output contains:

- `osm/kathmandu-valley.osm.pbf` — clipped OSM source
- `brouter/segments4/*.rd5` — offline BRouter routing segments
- `search/places.sqlite` — generated offline named-place index

After the data pack is installed on a phone, routing/search can operate without
mobile data or Wi-Fi. GPS itself is received from the phone's GNSS hardware.

## Accuracy policy

The pipeline uses the current Geofabrik Nepal extract and a conservative Valley
bounding box. It does not invent road geometry or POIs. OSM remains the source
of truth and must be quality-checked before each public release.
