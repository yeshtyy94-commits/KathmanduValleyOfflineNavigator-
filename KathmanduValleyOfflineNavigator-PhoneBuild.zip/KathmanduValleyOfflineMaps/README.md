# Kathmandu Valley Offline Navigator

A production-oriented Android navigation project for **Kathmandu + Lalitpur + Bhaktapur**.

## Product target

The target release is an offline-first navigation app: after the map/routing/search data pack has been installed, the core map, GPS positioning, place search and route calculation do not require mobile data or Wi-Fi.

GPS positioning itself comes from the phone's GNSS receiver; Internet is not required for a GPS fix.

## Current source includes

- MapLibre Native Android map
- Kathmandu Valley offline map-region caching
- GPS location and continuous foreground location service
- Long-press destination selection
- Landmark search fallback
- BRouter Android-service integration
- BRouter compressed-result decoding
- Route line rendering
- Foreground navigation service foundation
- Text-to-speech initialization
- Android 15 / SDK 35 target
- Debug CI and release CI workflows
- Production data-pipeline helper
- OSM/OpenFreeMap attribution

## What must be present for a true public navigation release

The APK alone does not contain the huge OSM routing database. The production release needs a versioned data pack containing:

1. Current Kathmandu Valley OSM map data.
2. BRouter `.rd5` routing data and matching profiles/configuration.
3. Generated offline road/place search database.
4. A map style/tile pack or a one-time offline map installation procedure.
5. Checksums and a data version so updates can be verified.

BRouter documents that its routing data is stored as 5x5-degree `.rd5` tiles and that official segment tiles are rebuilt weekly; it also documents building segments from OSM/GeoFabrik extracts. citeturn3search0turn3search1

## Build the data pack

Requires Docker and Internet during the build only:

```bash
./tools/data-pipeline/build-valley-data.sh
```

The output is under `data/kathmandu-valley/`.

**Important:** the official BRouter tile is a 5x5-degree tile that covers a larger area than Kathmandu Valley. The app UI remains Valley-focused, while the routing engine uses the tile it needs for the region.

## Data quality

The app must not claim permanent 100% accuracy. OpenStreetMap is community-maintained and changes over time; the OSM Kathmandu project explicitly aims for a complete, accurate and useful map of Kathmandu Valley. citeturn0search0turn0search7

For every public release, validate at least:

- Kathmandu ↔ Lalitpur
- Kathmandu ↔ Bhaktapur
- Tribhuvan International Airport ↔ Thamel
- Ring Road crossings
- One-way streets
- Bridges and restricted roads
- GPS off-route recalculation
- Nepali and English place names
- Driving, walking and motorcycle profiles

## Build APK

Open in Android Studio with JDK 17 and Android SDK 35, or use the included GitHub Actions workflows. The repository uses Gradle 8.10.2 through CI.

The release workflow produces an unsigned release APK unless you add your own signing configuration/secrets.

## Play Store launch requirements still needed

Before publishing, add:

- A real application ID owned by the publisher
- App icon and adaptive icon
- Signed AAB release configuration
- Privacy policy URL
- Data safety declaration
- OSM attribution screen
- Crash/ANR testing
- Battery/background-location testing
- Device testing on real Kathmandu roads
- A tested versioned offline data-pack update mechanism

## Licensing

OpenStreetMap data is licensed under ODbL and requires appropriate attribution. Review MapLibre/OpenFreeMap and BRouter licenses/terms before commercial distribution.

## Build from an Android phone

This repository includes a GitHub Actions workflow that builds an installable debug APK in the cloud. See `BUILD_FROM_PHONE.md`.

The quickest path is: upload the project contents to GitHub -> Actions -> **Build APK for Phone** -> Run workflow -> download the APK artifact to your phone.

The debug APK is for testing. A production Play Store release requires a signed release package and complete production offline map/routing/search data.
