package com.example.kathmanduoffline

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import org.json.JSONObject
import android.util.Base64
import java.io.ByteArrayInputStream
import java.util.zip.GZIPInputStream
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.maps.MapView
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.Style
import org.maplibre.android.offline.OfflineManager
import org.maplibre.android.offline.OfflineRegion
import org.maplibre.android.offline.OfflineRegionError
import org.maplibre.android.offline.OfflineRegionStatus
import org.maplibre.android.offline.OfflineTilePyramidRegionDefinition
import org.maplibre.android.style.layers.LineLayer
import org.maplibre.android.style.layers.PropertyFactory.lineColor
import org.maplibre.android.style.layers.PropertyFactory.lineWidth
import org.maplibre.android.style.sources.GeoJsonSource
import btools.routingapp.IBRouterService

class MainActivity : AppCompatActivity() {
    private lateinit var mapView: MapView
    private lateinit var map: MapLibreMap
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var navigateButton: Button
    private lateinit var downloadButton: Button

    private var youMarker: Marker? = null
    private var destinationMarker: Marker? = null
    private var offlineRegion: OfflineRegion? = null
    private var brouter: IBRouterService? = null
    private var brouterBound = false
    private var destination: LatLng? = null
    private var routeJson: JSONObject? = null

    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val prefs by lazy { getSharedPreferences("state", MODE_PRIVATE) }

    private val styleUrl = "https://tiles.openfreemap.org/styles/liberty"
    private val regionName = "Kathmandu Valley Offline Base Map"
    private val valleyBounds = LatLngBounds.Builder()
        .include(LatLng(27.55, 85.20))
        .include(LatLng(27.85, 85.55))
        .build()

    data class Poi(val name: String, val city: String, val lat: Double, val lon: Double, val type: String)
    private val pois = listOf(
        Poi("Kathmandu Durbar Square", "Kathmandu", 27.7040, 85.3070, "Heritage"),
        Poi("Patan Durbar Square", "Lalitpur", 27.6734, 85.3250, "Heritage"),
        Poi("Bhaktapur Durbar Square", "Bhaktapur", 27.6720, 85.4281, "Heritage"),
        Poi("Swayambhunath", "Kathmandu", 27.7150, 85.2900, "Temple"),
        Poi("Boudhanath Stupa", "Kathmandu", 27.7214, 85.3619, "Stupa"),
        Poi("Pashupatinath Temple", "Kathmandu", 27.7097, 85.3486, "Temple"),
        Poi("Thamel", "Kathmandu", 27.7091, 85.3061, "District"),
        Poi("Tribhuvan International Airport", "Kathmandu", 27.6912, 85.3553, "Airport")
    )

    private val brouterConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            brouter = IBRouterService.Stub.asInterface(service)
            brouterBound = true
            status.text = "Offline routing engine connected."
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            brouter = null
            brouterBound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MapLibre.getInstance(this)
        buildUi()
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync { m ->
            map = m
            map.setStyle(Style.Builder().fromUri(styleUrl)) { style ->
                map.cameraPosition = CameraPosition.Builder()
                    .target(LatLng(27.7172, 85.3240)).zoom(11.4).build()
                addPois()
                installMapGestures()
                status.text = if (hasOfflineMap()) "Offline map ready ✓" else "Download the Valley map once while online."
            }
        }
        refreshOfflineRegion()
        connectBRouterIfInstalled()
    }

    private fun buildUi() {
        val root = FrameLayout(this)
        mapView = MapView(this)
        root.addView(mapView, FrameLayout.LayoutParams(-1, -1))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.WHITE)
        }
        val title = TextView(this).apply {
            text = "Kathmandu Valley Offline Navigator"
            textSize = 19f
            setTextColor(Color.BLACK)
        }
        card.addView(title)

        val search = EditText(this).apply {
            hint = "Search Kathmandu, Lalitpur or Bhaktapur"
            singleLine = true
        }
        card.addView(search)

        val row1 = LinearLayout(this)
        fun btn(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { action() }
        }
        row1.addView(btn("My location") { locate() }, LinearLayout.LayoutParams(0, -2, 1f))
        downloadButton = btn("Offline map") { downloadOfflineMap() }
        row1.addView(downloadButton, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(row1)

        navigateButton = btn("Navigate to destination") { calculateRoute() }
        card.addView(navigateButton)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        card.addView(progress)

        status = TextView(this).apply {
            text = "Long-press the map to choose a destination."
            textSize = 12f
            setTextColor(Color.DKGRAY)
        }
        card.addView(status)

        search.setOnEditorActionListener { _, _, _ ->
            searchPoi(search.text.toString().trim())
            true
        }

        root.addView(card, FrameLayout.LayoutParams(-1, -2).apply { setMargins(16, 28, 16, 0) })
        root.addView(TextView(this).apply {
            text = "© OpenStreetMap contributors · OpenFreeMap"
            textSize = 10f
            setTextColor(Color.DKGRAY)
            setBackgroundColor(Color.argb(190, 255, 255, 255))
            setPadding(8, 5, 8, 5)
        }, FrameLayout.LayoutParams(-2, -2).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            setMargins(10, 0, 0, 10)
        })
        setContentView(root)
    }

    private fun installMapGestures() {
        map.addOnMapLongClickListener { point ->
            destination = point
            destinationMarker?.remove()
            destinationMarker = map.addMarker(MarkerOptions().position(point).title("Destination"))
            status.text = "Destination selected. Tap Navigate to calculate an offline route."
            true
        }
    }

    private fun addPois() {
        pois.forEach { p ->
            map.addMarker(MarkerOptions().position(LatLng(p.lat, p.lon)).title(p.name).snippet("${p.city} · ${p.type}"))
        }
    }

    private fun searchPoi(query: String) {
        if (query.isBlank()) return
        val p = pois.firstOrNull { it.name.contains(query, true) || it.city.contains(query, true) }
        if (p == null) {
            status.text = "No bundled POI match. A full release should include the generated OSM search database."
            return
        }
        destination = LatLng(p.lat, p.lon)
        destinationMarker?.remove()
        destinationMarker = map.addMarker(MarkerOptions().position(destination!!).title(p.name))
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(destination!!, 15.5))
        status.text = "${p.name} selected. Tap Navigate."
    }

    private fun hasLocationPermission() = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun locate() {
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 100)
            return
        }
        fused.lastLocation.addOnSuccessListener { loc ->
            if (loc == null) {
                status.text = "Waiting for a GPS fix. GPS itself works without mobile data."
                return@addOnSuccessListener
            }
            val p = LatLng(loc.latitude, loc.longitude)
            youMarker?.remove()
            youMarker = map.addMarker(MarkerOptions().position(p).title("You are here"))
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(p, 15.0))
        }
    }

    private fun connectBRouterIfInstalled() {
        try {
            val intent = Intent().setClassName("btools.routingapp", "btools.routingapp.BRouterService")
            brouterBound = bindService(intent, brouterConnection, Context.BIND_AUTO_CREATE)
        } catch (_: Exception) {
            brouterBound = false
        }
    }

    private fun calculateRoute() {
        val dest = destination
        if (dest == null) {
            status.text = "Long-press the map or search for a place first."
            return
        }
        if (!hasLocationPermission()) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 100)
            return
        }
        if (!brouterBound || brouter == null) {
            AlertDialog.Builder(this)
                .setTitle("Offline routing engine not installed")
                .setMessage("The map works offline after its download. Turn-by-turn offline routing in this release uses the BRouter Android routing service. Install BRouter and its Kathmandu Valley routing data once, then this app can request routes without internet.")
                .setPositiveButton("OK", null).show()
            return
        }
        fused.lastLocation.addOnSuccessListener { loc ->
            if (loc == null) { status.text = "No GPS fix yet."; return@addOnSuccessListener }
            Thread {
                try {
                    val params = Bundle().apply {
                        putString("lonlats", "${loc.longitude},${loc.latitude}|${dest.longitude},${dest.latitude}")
                        putString("v", "motorcar")
                        putString("fast", "1")
                        putString("format", "geojson")
                        putString("acceptCompressedResult", "true")
                    }
                    val result = brouter!!.getTrackFromParams(params)
                    runOnUiThread { showRouteResult(result) }
                } catch (e: Exception) {
                    runOnUiThread { status.text = "Offline route failed: ${e.message}" }
                }
            }.start()
        }
    }

    private fun showRouteResult(raw: String) {
        try {
            val text = decodeBRouterResult(raw)
            val json = JSONObject(text)
            routeJson = json
            drawRoute(json)
            status.text = "Offline route calculated ✓. Start navigation for live GPS guidance."
            startNavigationService(json.toString())
        } catch (e: Exception) {
            status.text = "Could not read route result: ${e.message}"
        }
    }


    private fun decodeBRouterResult(raw: String): String {
        if (!raw.startsWith("z64")) return raw
        val encoded = raw.removePrefix("z64").trim()
        val compressed = Base64.decode(encoded, Base64.DEFAULT)
        GZIPInputStream(ByteArrayInputStream(compressed)).use { input ->
            return input.bufferedReader(Charsets.UTF_8).readText()
        }
    }

    private fun drawRoute(json: JSONObject) {
        val style = map.style ?: return
        style.removeLayer("route-line")
        style.removeSource("route-source")
        style.addSource(GeoJsonSource("route-source", json.toString()))
        style.addLayer(LineLayer("route-line", "route-source").withProperties(lineColor("#1565C0"), lineWidth(6f)))
    }

    private fun startNavigationService(route: String) {
        val i = Intent(this, NavigationService::class.java).putExtra("route_geojson", route)
        ActivityCompat.startForegroundService(this, i)
        Toast.makeText(this, "Navigation started. Keep GPS enabled.", Toast.LENGTH_SHORT).show()
    }

    private fun hasOfflineMap() = prefs.getBoolean("offline_complete", false)

    private fun downloadOfflineMap() {
        if (offlineRegion != null) { status.text = "Kathmandu Valley map is already installed offline."; return }
        val manager = OfflineManager.getInstance(this)
        val definition = OfflineTilePyramidRegionDefinition(styleUrl, valleyBounds, 8.0, 16.0, resources.displayMetrics.density)
        progress.visibility = View.VISIBLE
        downloadButton.isEnabled = false
        manager.createOfflineRegion(definition, regionName.toByteArray(), object : OfflineManager.CreateOfflineRegionCallback {
            override fun onCreate(region: OfflineRegion) {
                offlineRegion = region
                region.setObserver(object : OfflineRegion.OfflineRegionObserver {
                    override fun onStatusChanged(s: OfflineRegionStatus?) {
                        if (s == null) return
                        val pct = if (s.requiredResourceCount == 0L) 0 else ((s.completedResourceCount * 100L) / s.requiredResourceCount).toInt()
                        runOnUiThread {
                            progress.progress = pct
                            status.text = "Downloading Valley map: $pct% (${s.completedResourceCount}/${s.requiredResourceCount})"
                            if (s.isComplete) {
                                prefs.edit().putBoolean("offline_complete", true).apply()
                                downloadButton.isEnabled = true
                                status.text = "Kathmandu + Lalitpur + Bhaktapur map ready for offline use ✓"
                            }
                        }
                    }
                    override fun onError(error: OfflineRegionError?) { runOnUiThread { downloadButton.isEnabled = true; status.text = "Download error: ${error?.message}" } }
                    override fun mapboxTileCountLimitExceeded(limit: Long) { runOnUiThread { status.text = "Map tile limit reached: $limit" } }
                })
                region.setDownloadState(OfflineRegion.STATE_ACTIVE)
            }
            override fun onError(error: String) { runOnUiThread { downloadButton.isEnabled = true; progress.visibility = View.GONE; status.text = error } }
        })
    }

    private fun refreshOfflineRegion() {
        OfflineManager.getInstance(this).listOfflineRegions(object : OfflineManager.ListOfflineRegionsCallback {
            override fun onList(regions: Array<OfflineRegion>?) {
                val r = regions?.firstOrNull { String(it.metadata) == regionName }
                if (r != null) {
                    offlineRegion = r
                    prefs.edit().putBoolean("offline_complete", true).apply()
                    runOnUiThread { status.text = "Offline map installed ✓" }
                }
            }
            override fun onError(error: String) { }
        })
    }

    override fun onDestroy() {
        if (brouterBound) unbindService(brouterConnection)
        mapView.onDestroy()
        super.onDestroy()
    }
    override fun onStart() { super.onStart(); mapView.onStart() }
    override fun onResume() { super.onResume(); mapView.onResume() }
    override fun onPause() { mapView.onPause(); super.onPause() }
    override fun onStop() { mapView.onStop(); super.onStop() }
    override fun onLowMemory() { super.onLowMemory(); mapView.onLowMemory() }
}
