package com.example.kathmanduoffline

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import java.util.Locale
import kotlin.math.*

class NavigationService : Service(), TextToSpeech.OnInitListener {
    private lateinit var fused: FusedLocationProviderClient
    private var tts: TextToSpeech? = null
    private var lastSpoken = ""
    private var lastLat = Double.NaN
    private var lastLon = Double.NaN

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7001, notification("Offline navigation active"))
        fused = LocationServices.getFusedLocationProviderClient(this)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        requestLocationUpdates()
        return START_STICKY
    }

    private fun requestLocationUpdates() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000L)
            .setMinUpdateIntervalMillis(500L)
            .setMinUpdateDistanceMeters(2f)
            .build()
        try {
            fused.requestLocationUpdates(request, callback, mainLooper)
        } catch (_: SecurityException) { stopSelf() }
    }

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            val l = result.lastLocation ?: return
            lastLat = l.latitude
            lastLon = l.longitude
            val speed = if (l.hasSpeed()) " ${"%.0f".format(l.speed * 3.6)} km/h" else ""
            val nm = "GPS ${"%.5f".format(lastLat)}, ${"%.5f".format(lastLon)}$speed"
            getSystemService(NotificationManager::class.java)?.notify(7001, notification(nm))
        }
    }

    private fun notification(text: String) = NotificationCompat.Builder(this, "navigation")
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setContentTitle("Kathmandu Valley Navigator")
        .setContentText(text)
        .setOngoing(true)
        .build()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("navigation", "Navigation", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.US
    }

    private fun speak(text: String) {
        if (text != lastSpoken) {
            lastSpoken = text
            tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "nav")
        }
    }

    override fun onDestroy() {
        fused.removeLocationUpdates(callback)
        tts?.stop(); tts?.shutdown()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
